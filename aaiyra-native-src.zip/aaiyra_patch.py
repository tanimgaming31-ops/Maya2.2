#!/usr/bin/env python3
"""Non-destructive Kotlin+Compose overlay on EXISTING Capacitor 6 Android build.
Runs AFTER npx cap add android / bash setup-native.sh. Does not replace the old Maya Bridge.
"""
import shutil, re
from pathlib import Path
src=Path('aaiyra-native-src/native/app/src/main/java')
target=Path('android/app/src/main/java')
if not (Path('android/app/build.gradle').is_file() and Path('android/build.gradle').is_file()):
    raise SystemExit('Run after Capacitor has created android/ project')
for file in src.rglob('*.kt'):
    rel=file.relative_to(src)
    dest=target/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(file,dest)

root=Path('android/build.gradle')
s=root.read_text()
if 'kotlin-gradle-plugin' not in s:
    idx=s.index('dependencies {',s.index('buildscript'))
    s=s[:idx]+s[idx:].replace('dependencies {',"dependencies {\n        classpath 'org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24'",1)
root.write_text(s)

app=Path('android/app/build.gradle')
s=app.read_text()
if "apply plugin: 'kotlin-android'" not in s:
    if "apply plugin: 'com.android.application'" not in s:
        raise SystemExit('Missing Android application plugin')
    s=s.replace("apply plugin: 'com.android.application'", "apply plugin: 'com.android.application'\napply plugin: 'kotlin-android'", 1)
if 'kotlinCompilerExtensionVersion' not in s:
    block='''\nandroid {
    buildFeatures { compose true }
    composeOptions { kotlinCompilerExtensionVersion '1.5.14' }
    kotlinOptions { jvmTarget = '17' }
    compileSdkVersion 35
}
'''
    s+=block
if 'androidx.activity:activity-compose' not in s:
    s+='''\ndependencies {
    implementation platform('androidx.compose:compose-bom:2024.12.01')
    implementation 'androidx.activity:activity-compose:1.9.3'
    implementation 'androidx.compose.ui:ui'
    implementation 'androidx.compose.foundation:foundation'
    implementation 'androidx.compose.material3:material3'
    implementation 'androidx.compose.ui:ui-tooling-preview'
    implementation 'androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7'
    implementation 'androidx.lifecycle:lifecycle-runtime-compose:2.8.7'
    implementation 'com.squareup.okhttp3:okhttp:4.12.0'
}
'''
app.write_text(s)

manifest=Path('android/app/src/main/AndroidManifest.xml')
s=manifest.read_text()
for p in ['android.permission.READ_CONTACTS','android.permission.CALL_PHONE','android.permission.FOREGROUND_SERVICE_MICROPHONE','android.permission.RECORD_AUDIO','android.permission.POST_NOTIFICATIONS']:
    if 'android:name="'+p+'"' not in s:
        s=s.replace('<application',f'    <uses-permission android:name="{p}" />\n    <application',1)
# Launch intent moves to Compose Activity. Existing Capacitor MainActivity stays launchable from Compose.
activity=re.search(r'<activity\b[^>]*\bandroid:name="[^\"]*MainActivity"[^>]*>.*?</activity>',s,re.S)
if not activity:
    raise SystemExit('Could not find existing Capacitor MainActivity; refusing to patch manifest')
old=activity.group(0)
new=re.sub(r'<intent-filter>\s*<action android:name="android.intent.action.MAIN"\s*/>\s*<category android:name="android.intent.category.LAUNCHER"\s*/>\s*</intent-filter>', '',old,flags=re.S)
if new==old:
    # Capacitor may add category DEFAULT; robustly drop all launcher filters only.
    new=re.sub(r'<intent-filter>.*?android.intent.category.LAUNCHER.*?</intent-filter>','',old,flags=re.S)
if new==old:
    raise SystemExit('Cannot identify existing LAUNCHER intent filter safely')
s=s.replace(old,new,1)
extra='''\n    <activity android:name="com.tanim.maya2.aaiyra.ui.MainActivity" android:exported="true" android:launchMode="singleTop">
      <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
      </intent-filter>
    </activity>
    <service android:name="com.tanim.maya2.aaiyra.service.BackgroundAudioService" android:exported="false" android:foregroundServiceType="microphone" />\n'''
s=s.replace('</application>',extra+'  </application>',1)
manifest.write_text(s)
print('Kotlin/Compose Voice Activity added without removing original Maya Bridge')
