package com.tanim.maya2.aaiyra.tools

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.tanim.maya2.aaiyra.ui.AssistantBus
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

/** All actions are user-visible. Calls, messages and email require confirmation. */
class ToolExecutionEngine(private val context: Context) {
    private val pending = ConcurrentHashMap<String, AssistantBus.Pending>()
    companion object {
        val declarations = JSONArray().apply {
            fun add(n:String,desc:String,req:List<String>) {
                val props=JSONObject();req.forEach{props.put(it,JSONObject().put("type","STRING"))}
                put(JSONObject().put("name",n).put("description",desc)
                    .put("parameters",JSONObject().put("type","OBJECT").put("properties",props).put("required",JSONArray(req))))
            }
            add("openApp","Launch a user-requested installed Android application by its package name.",listOf("packageName"))
            add("searchAndCallContact","Find contact by name; request confirmation before starting a phone call.",listOf("contactName"))
            add("sendWhatsAppMessage","Find contact; prepare WhatsApp with text; user must press Send.",listOf("contactName","message"))
            add("sendGmail","Compose a Gmail or email message and request confirmation; user presses Send.",listOf("recipientEmail","subject","body"))
        }
    }
    private fun allowed(permission:String)=ContextCompat.checkSelfPermission(context,permission)==PackageManager.PERMISSION_GRANTED
    fun execute(callId:String,name:String,args:JSONObject):JSONObject {
        if(name=="openApp")return openApp(args.optString("packageName"))
        if(name !in setOf("searchAndCallContact","sendWhatsAppMessage","sendGmail"))return reply("error","Unknown tool")
        if(name=="searchAndCallContact" || name=="sendWhatsAppMessage") {
            if(!allowed(Manifest.permission.READ_CONTACTS))return reply("permission_required","Contacts access, darling — I can’t find your people without it. Please enable it in Settings.")
        }
        val explanation=when(name){
            "searchAndCallContact"->"Call ${args.optString("contactName")}?"
            "sendWhatsAppMessage"->"Open WhatsApp message to ${args.optString("contactName")}: ${args.optString("message").take(90)}?"
            else->"Compose email to ${args.optString("recipientEmail")}: ${args.optString("subject")}?"
        }
        val p=AssistantBus.Pending(callId,name,args,explanation)
        pending[callId]=p;AssistantBus.pending.value=p
        return reply("confirmation_required","User confirmation needed in Maya. No message, email or call has been sent.")
    }
    fun approve(id:String):JSONObject {
        val p=pending.remove(id)?:return reply("cancelled","Nothing pending")
        AssistantBus.pending.value=null
        return when(p.name){
            "searchAndCallContact"->callContact(p.arguments.optString("contactName"))
            "sendWhatsAppMessage"->whatsapp(p.arguments.optString("contactName"),p.arguments.optString("message"))
            "sendGmail"->gmail(p.arguments.optString("recipientEmail"),p.arguments.optString("subject"),p.arguments.optString("body"))
            else->reply("error","Unknown tool")
        }
    }
    fun decline(id:String):JSONObject {pending.remove(id);AssistantBus.pending.value=null;return reply("cancelled","User declined")}
    private fun reply(status:String,message:String)=JSONObject().put("status",status).put("message",message)
    private fun launch(intent:Intent):JSONObject=try { intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(intent);reply("opened","App was opened; final sending requires user action.") }catch(e:Exception){reply("error",e.message?:"Could not open app")}
    private fun openApp(pkg:String):JSONObject{
        if(!pkg.matches(Regex("[a-zA-Z0-9_]+(\\.[a-zA-Z0-9_]+)+")))return reply("error","Invalid package name")
        val intent=context.packageManager.getLaunchIntentForPackage(pkg)?:return reply("not_found","App is not installed or not visible to this app")
        return launch(intent)
    }
    private fun phone(name:String):String? {
        if(name.isBlank())return null
        val projection=arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val where="${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        var number: String? = null
        context.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,projection,where,arrayOf("%$name%"),null)?.use { cursor ->
            if(cursor.moveToFirst())number=cursor.getString(0)
        }
        return number
    }
    private fun callContact(name:String):JSONObject{
        if(!allowed(Manifest.permission.READ_CONTACTS))return reply("permission_required","Please enable Contacts permission first, then I can work my magic.")
        val number=phone(name)?:return reply("not_found","Contact not found")
        val uri=Uri.fromParts("tel",number,null)
        return if(allowed(Manifest.permission.CALL_PHONE)) launch(Intent(Intent.ACTION_CALL,uri))
            else launch(Intent(Intent.ACTION_DIAL,uri))
    }
    private fun whatsapp(name:String,message:String):JSONObject{
        val number=phone(name)?.filter{it.isDigit()}?:return reply("not_found","Contact not found")
        val uri=Uri.parse("https://wa.me/$number?text=${Uri.encode(message)}")
        return launch(Intent(Intent.ACTION_VIEW,uri))
    }
    private fun gmail(email:String,subject:String,body:String):JSONObject{
        if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches())return reply("error","Enter a valid email address")
        val intent=Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:${Uri.encode(email)}"))
            .putExtra(Intent.EXTRA_EMAIL,arrayOf(email))
            .putExtra(Intent.EXTRA_SUBJECT,subject).putExtra(Intent.EXTRA_TEXT,body)
        return launch(intent)
    }
}
