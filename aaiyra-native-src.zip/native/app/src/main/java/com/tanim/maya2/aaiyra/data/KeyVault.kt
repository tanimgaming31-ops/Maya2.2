package com.tanim.maya2.aaiyra.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Device-only, AndroidKeyStore-backed storage. Never include API keys in repo or intent extras. */
class KeyVault(private val context: Context) {
    private val prefs = context.getSharedPreferences("aaiyra_vault", Context.MODE_PRIVATE)
    private val alias = "aaiyra_key_v1"
    private fun secret(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").also { it.load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return kg.generateKey()
    }
    fun save(key: String) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, secret())
        val result = Base64.encodeToString(c.iv + c.doFinal(key.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
        prefs.edit().putString("secret", result).apply()
    }
    fun read(): String? {
        return try {
            val value = prefs.getString("secret", null) ?: return null
            val bytes = Base64.decode(value, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, secret(), GCMParameterSpec(128, bytes.copyOfRange(0,12)))
            String(c.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }
    fun clear() { prefs.edit().remove("secret").apply() }
}
