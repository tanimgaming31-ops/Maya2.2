package com.tanim.maya2.aaiyra.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel

private val midnight=Color(0xFF020205)
private val violet=Color(0xFFAF72FF)
private val cyan=Color(0xFF64DFFE)
class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { MaterialTheme(colorScheme=darkColorScheme(background=midnight,primary=violet,surface=Color(0xFF101028))) { NativeScreen() } }}}

@Composable fun NativeScreen(vm:AssistantViewModel=viewModel()) {
    val ctx=LocalContext.current; val state by vm.state.collectAsState();val pending by vm.pending.collectAsState()
    var screen by remember { mutableStateOf("voice") }
    var key by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(vm.vault.read()!=null) }
    var permissionRevision by remember { mutableIntStateOf(0) }
    val permissions= remember { buildList {
        add(Manifest.permission.RECORD_AUDIO);add(Manifest.permission.READ_CONTACTS);add(Manifest.permission.CALL_PHONE)
        if(Build.VERSION.SDK_INT>=33)add(Manifest.permission.POST_NOTIFICATIONS)
    } }
    val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){permissionRevision++}
    val missing=remember(permissionRevision){permissions.filter{ContextCompat.checkSelfPermission(ctx,it)!=PackageManager.PERMISSION_GRANTED}}
    if(screen=="classic") {
        Column(Modifier.fillMaxSize().background(midnight)) {
            TextButton(onClick={screen="voice"}){Text("← Native Aaiyra Voice")}
            ClassicMayaWeb(Modifier.weight(1f))
        };return
    }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(midnight,Color(0xFF09091C),midnight))).padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){
            Column {Text("MAYA 4",fontSize=22.sp,fontWeight=FontWeight.Bold,color=Color.White);Text("AAIYRA • NATIVE VOICE",fontSize=11.sp,color=cyan)}
            TextButton(onClick={screen=if(screen=="settings")"voice" else "settings"}){Text(if(screen=="settings")"Back" else "Settings")}
        }
        if(screen=="settings"){
            Spacer(Modifier.height(12.dp));Text("First-time setup",fontSize=20.sp,color=Color.White)
            Spacer(Modifier.height(12.dp));Text("Your Gemini key stays encrypted on this phone. It is sent only to Google when you start voice.",color=Color.LightGray)
            Spacer(Modifier.height(12.dp));OutlinedTextField(key,{key=it},label={Text("Gemini API key")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                Button(onClick={if(key.trim().isNotEmpty()){vm.vault.save(key.trim());saved=true;key=""}}){Text("Save key")}
                OutlinedButton(onClick={vm.vault.clear();saved=false;key=""}){Text("Remove key")}
            }
            Text(if(saved)"Key stored (encrypted)" else "No key stored",color=if(saved)cyan else Color.Yellow)
            Spacer(Modifier.height(12.dp));Text("Permissions: ${permissions.size-missing.size}/${permissions.size}",color=Color.White)
            if(missing.isNotEmpty())Button(onClick={launcher.launch(missing.toTypedArray())}){Text("Allow microphone, contacts, calls and notifications")}
            Spacer(Modifier.height(12.dp));Text("Wake word",color=Color.White,fontSize=18.sp)
            Text("Locally trained with three spoken examples. Experimental voice fingerprint: can miss 'Aaiyra' or trigger incorrectly. Audio never uploaded during wake monitoring.",color=Color.LightGray)
            OutlinedButton(onClick={if(state.serviceRunning)vm.train() else vm.begin()}){Text(if(state.serviceRunning)"Train 'Aaiyra' (3 times)" else "Start microphone first")}
            Text("Training sample: ${state.enrolling} • ${state.details}",color=Color.LightGray)
            Spacer(Modifier.height(16.dp));HorizontalDivider()
            TextButton(onClick={screen="classic"}){Text("Open original Maya 3D / Memory / Camera / Messages")}
            Text("Classic mode retains the original website inside this app; using it may require internet and its own API-key settings.",color=Color.LightGray,fontSize=11.sp)
        }else{
            Spacer(Modifier.weight(.7f))
            VoiceOrb(state.micLevel,state.outputLevel,state.status,Modifier.size(280.dp))
            Spacer(Modifier.height(25.dp));Text(state.status,color=Color.White,fontSize=22.sp)
            Text(if(state.wakeReady)"Say ‘Aaiyra’ to awaken" else "Train a wake word in Settings, or tap Talk",color=Color.LightGray,fontSize=12.sp)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){
                Button(onClick={if(missing.contains(Manifest.permission.RECORD_AUDIO))launcher.launch(arrayOf(Manifest.permission.RECORD_AUDIO)) else vm.begin()},enabled=!state.serviceRunning){Text("Start Listening")}
                OutlinedButton(onClick={vm.talk()},enabled=state.serviceRunning){Text("Talk Now")}
                OutlinedButton(onClick={vm.stop()},enabled=state.serviceRunning){Text("Stop")}
            }
            Spacer(Modifier.height(18.dp));Text("${state.details}  •  Microphone notification stays visible while active",color=Color.Gray,fontSize=11.sp)
        }
    }
    if(pending!=null){ val p=pending!!
        AlertDialog(onDismissRequest={vm.confirm(p.callId,false)},title={Text("Confirm action")},text={Text(p.explanation)},
            confirmButton={TextButton(onClick={vm.confirm(p.callId,true)}){Text("Allow")}},
            dismissButton={TextButton(onClick={vm.confirm(p.callId,false)}){Text("Cancel")}})
    }
}
@Composable fun VoiceOrb(mic:Float,output:Float,status:String,modifier:Modifier=Modifier){
    val breathe=remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            breathe.animateTo(1f, tween(2100, easing=FastOutSlowInEasing))
            breathe.animateTo(0f, tween(2100, easing=FastOutSlowInEasing))
        }
    }
    val wave=breathe.value
    val activity=(maxOf(mic,output)*8f).coerceIn(0f,1f)
    Canvas(modifier){val center=Offset(size.width/2,size.height/2);val rad=size.minDimension/2
        drawCircle(brush=Brush.radialGradient(listOf(violet.copy(alpha=.18f+activity*.2f),Color.Transparent)),radius=rad)
        for(i in 0..3){val offset=i*14.dp.toPx()+wave*10.dp.toPx()
            drawCircle(if(status=="Speaking")cyan else violet, radius=rad*.56f+offset,
                alpha=(.55f-i*.10f+activity*.16f).coerceIn(0f,1f),style=Stroke(width=(2.5f+activity*2).dp.toPx(),cap=StrokeCap.Round))}
        drawCircle(brush=Brush.radialGradient(listOf(Color(0xFF9E76FA),Color(0xFF35226C),Color(0xFF0D0923))),radius=rad*.56f)
        val bars=18;val w=size.width/(bars*2.2f)
        for(i in 0 until bars){val height=(12f+(if(status=="Listening")mic else output)*100f+wave*12f*(i%3)/3).dp.toPx()
            val x=center.x+(i-(bars-1)/2f)*w*1.65f
            drawLine(Color.White.copy(alpha=.65f),Offset(x,center.y-height/2),Offset(x,center.y+height/2),strokeWidth=w*.47f,cap=StrokeCap.Round)}
    }
}
@Composable fun ClassicMayaWeb(modifier:Modifier=Modifier){
    val context=LocalContext.current
    LaunchedEffect(Unit){
        try{
            val nativeActivity=Class.forName("com.tanim.maya2.MainActivity")
            context.startActivity(Intent(context,nativeActivity))
        }catch(e:Exception){AssistantBus.update{it.copy(details="Cannot open classic Maya: ${e.message}")}}
    }
    Box(modifier,contentAlignment=Alignment.Center){Text("Opening original Maya 3D...",color=Color.White)}
}
