package com.tanim.maya2.aaiyra.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.util.Base64
import com.tanim.maya2.aaiyra.ui.AssistantBus
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/** PCM16 mono output from Gemini Live typically 24kHz. Safe bounded queue and cut-off on barge-in. */
class PcmPlayer(private val sampleRate: Int = 24000) {
    private val queue = LinkedBlockingDeque<ByteArray>(90)
    private val alive = AtomicBoolean(true)
    private val player = AudioTrack.Builder()
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
        .setTransferMode(AudioTrack.MODE_STREAM)
        .setBufferSizeInBytes((AudioTrack.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT)).coerceAtLeast(sampleRate))
        .build()
    private val thread = Thread({
        try { player.play(); while(alive.get()) {
            val frame=queue.take(); var offset=0
            while (offset<frame.size && alive.get()) {
                val written=player.write(frame,offset,frame.size-offset)
                if(written<=0)break
                offset+=written
            }
            AssistantBus.update{it.copy(outputLevel=0f)}
        }}catch(_:InterruptedException){}catch(_:Exception){}
    },"Aaiyra-PcmOutput").apply{isDaemon=true;start()}
    fun enqueueB64(payload:String){
        val bytes=try{Base64.decode(payload,Base64.DEFAULT)}catch(_:Exception){return}
        if(bytes.isEmpty())return
        if(queue.remainingCapacity()==0)queue.poll()
        queue.offer(bytes)
        var v=0.0;val n=(bytes.size/2).coerceAtLeast(1)
        for(i in 0 until bytes.size/2 step 24){val k=i*2;val s=((bytes[k].toInt() and 255) or (bytes[k+1].toInt() shl 8)).toShort().toInt();v+=(s/32768.0)*(s/32768.0)}
        AssistantBus.update{it.copy(outputLevel=sqrt(v/(n/24+1)).toFloat().coerceIn(0f,1f))}
    }
    @Synchronized fun interrupt(){queue.clear();try{player.pause();player.flush();player.play()}catch(_:Exception){};AssistantBus.update{it.copy(outputLevel=0f)}}
    fun close(){alive.set(false);thread.interrupt();queue.clear();try{player.stop();player.release()}catch(_:Exception){}}
}
