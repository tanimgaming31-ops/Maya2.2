package com.tanim.maya2.aaiyra.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.tanim.maya2.aaiyra.audio.LocalWakeWord
import com.tanim.maya2.aaiyra.data.KeyVault
import com.tanim.maya2.aaiyra.live.LiveSessionManager
import com.tanim.maya2.aaiyra.tools.ToolExecutionEngine
import com.tanim.maya2.aaiyra.ui.AssistantBus
import com.tanim.maya2.aaiyra.ui.MainActivity
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/** Explicitly started microphone foreground service. No covert, boot-time, or immortal mic. */
class BackgroundAudioService:Service(){
    companion object {
        const val START="com.tanim.maya2.START"
        const val STOP="com.tanim.maya2.STOP"
        const val TRAIN="com.tanim.maya2.TRAIN"
        const val TALK="com.tanim.maya2.TALK"
        const val END="com.tanim.maya2.END"
        @Volatile private var active:BackgroundAudioService?=null
        fun confirm(id:String,allow:Boolean){active?.respond(id,allow)}
    }
    private val working=AtomicBoolean(false)
    private var recorder:AudioRecord?=null
    private var captureThread:Thread?=null
    private lateinit var detector:LocalWakeWord
    private lateinit var toolEngine:ToolExecutionEngine
    private lateinit var live:LiveSessionManager
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate(){super.onCreate();active=this;detector=LocalWakeWord(this);toolEngine=ToolExecutionEngine(this);live=LiveSessionManager(toolEngine);makeChannel()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        when(intent?.action){
            STOP->{stopSelf();return START_NOT_STICKY}
            TRAIN->{if(working.get())detector.startTraining()}
            TALK->{if(working.get())startLive()}
            END->{live.stop();AssistantBus.update{it.copy(status="Waiting for Aaiyra")}}
            else->startListening()
        }
        return START_NOT_STICKY
    }
    private fun makeChannel(){val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("aaiyra_mic","Aaiyra voice listening",NotificationManager.IMPORTANCE_LOW))}
    private fun notification():Notification {
        val open=PendingIntent.getActivity(this,10,Intent(this,MainActivity::class.java),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val stop=PendingIntent.getService(this,11,Intent(this,BackgroundAudioService::class.java).setAction(STOP),PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this,"aaiyra_mic").setContentTitle("Maya • Aaiyra Native Voice")
            .setContentText("Mic active • tap to open • Stop anytime")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
            .setContentIntent(open).addAction(android.R.drawable.ic_delete,"Stop microphone",stop).build()
    }
    private fun startListening(){
        if(working.get())return
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
            AssistantBus.update{it.copy(status="Microphone permission required")};stopSelf();return
        }
        try{
            if(Build.VERSION.SDK_INT>=29)startForeground(3209,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(3209,notification())
        }catch(e:Exception){AssistantBus.update{it.copy(status="Foreground mic denied: ${e.message}")};stopSelf();return}
        val rate=16000;val frameSize=320
        val minBytes=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        try{
            val ar=AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,(minBytes*2).coerceAtLeast(6400))
            if(ar.state!=AudioRecord.STATE_INITIALIZED)throw IllegalStateException("Microphone not initialized")
            recorder=ar;ar.startRecording();working.set(true)
            AssistantBus.update{it.copy(status=if(detector.trained)"Waiting for Aaiyra" else "Train wake phrase, or tap Talk",serviceRunning=true,wakeReady=detector.trained)}
            captureThread=Thread({
                val shorts=ShortArray(frameSize)
                while(working.get()){
                    val n=try{ar.read(shorts,0,shorts.size)}catch(_:Exception){break}
                    if(n<=0)continue
                    val pcm=ByteArray(n*2);var energy=0.0
                    for(i in 0 until n){val s=shorts[i].toInt();pcm[2*i]=(s and 255).toByte();pcm[2*i+1]=(s shr 8).toByte();energy+=s.toDouble()*s}
                    val level=sqrt(energy/n)/32768.0
                    AssistantBus.update{it.copy(micLevel=level.toFloat().coerceIn(0f,1f))}
                    // Only user-enrolled recordings are compared; no raw audio persisted.
                    if(!live.connected && detector.process(shorts.copyOf(n)))startLive()
                    if(live.connected){
                        if(level>0.08 && AssistantBus.states.value.outputLevel>0.07f)live.interrupt()
                        live.sendPcm16(pcm)
                    }
                }
            },"Aaiyra-AudioRecord").apply{isDaemon=true;start()}
        }catch(e:Exception){AssistantBus.update{it.copy(status="Microphone error: ${e.message}")};stopSelf()}
    }
    private fun startLive(){val key=KeyVault(this).read();if(key.isNullOrBlank()){
        AssistantBus.update{it.copy(status="Set Gemini API key in Settings")};return
    }; live.start(key)}
    private fun respond(id:String,allow:Boolean){
        val pending=AssistantBus.pending.value?:return
        if(pending.callId!=id)return
        val result=if(allow)toolEngine.approve(id)else toolEngine.decline(id)
        live.sendToolResult(id,pending.name,result)
        AssistantBus.update{it.copy(details=result.optString("message"))}
    }
    override fun onDestroy(){working.set(false);live.stop();try{recorder?.stop();recorder?.release()}catch(_:Exception){};captureThread?.interrupt();active=null
        AssistantBus.pending.value=null;AssistantBus.update{it.copy(status="Stopped",serviceRunning=false,micLevel=0f,sessionConnected=false,outputLevel=0f)};super.onDestroy()}
}
