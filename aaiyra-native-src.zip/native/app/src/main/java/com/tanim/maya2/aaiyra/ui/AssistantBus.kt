package com.tanim.maya2.aaiyra.ui

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

/** Service owns audio. Compose observes immutable status/confirmation state. */
object AssistantBus {
    data class State(val status: String="Idle", val micLevel: Float=0f,
                     val outputLevel: Float=0f, val serviceRunning: Boolean=false,
                     val sessionConnected: Boolean=false, val enrolling: Int=0,
                     val wakeReady: Boolean=false, val details: String="")
    private val mutable = MutableStateFlow(State())
    val states = mutable.asStateFlow()
    fun update(f: (State)->State) { mutable.value = f(mutable.value) }
    data class Pending(val callId: String, val name: String, val arguments: JSONObject, val explanation: String)
    val pending = MutableStateFlow<Pending?>(null)
}
