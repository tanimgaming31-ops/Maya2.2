package com.tanim.maya2.aaiyra.ui

import android.Manifest
import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.tanim.maya2.aaiyra.data.KeyVault
import com.tanim.maya2.aaiyra.service.BackgroundAudioService

/** MVVM ViewModel: Compose never owns the AudioRecord or websocket. */
class AssistantViewModel(application:Application):AndroidViewModel(application){
    val state=AssistantBus.states
    val pending=AssistantBus.pending
    val vault=KeyVault(application)
    private fun action(a:String){
        val app=getApplication<Application>();val intent=Intent(app,BackgroundAudioService::class.java).setAction(a)
        if(a==BackgroundAudioService.START)ContextCompat.startForegroundService(app,intent) else app.startService(intent)
    }
    fun begin()=action(BackgroundAudioService.START)
    fun stop()=action(BackgroundAudioService.STOP)
    fun train()=action(BackgroundAudioService.TRAIN)
    fun talk()=action(BackgroundAudioService.TALK)
    fun endCall()=action(BackgroundAudioService.END)
    fun confirm(id:String,yes:Boolean){BackgroundAudioService.confirm(id,yes)}
}
