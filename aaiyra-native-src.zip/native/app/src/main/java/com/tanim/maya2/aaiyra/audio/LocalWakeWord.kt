package com.tanim.maya2.aaiyra.audio

import android.content.Context
import com.tanim.maya2.aaiyra.ui.AssistantBus
import org.json.JSONArray
import kotlin.math.*

/**
 * Fully on-device *experimental* user-enrolled wake phrase matcher.
 * NOT a commercially trained keyword classifier. Three spoken 'Aaiyra' examples are required.
 * Local AudioRecord -> voice activity segmentation -> spectral features -> DTW.
 * Never uploads recordings and never persist raw PCM. May yield false negatives/positives.
 */
class LocalWakeWord(private val context: Context) {
    private val frequencies=doubleArrayOf(260.0,390.0,580.0,820.0,1180.0,1650.0,2320.0,3100.0)
    private val prefs=context.getSharedPreferences("aaiyra_wake", Context.MODE_PRIVATE)
    private val samples=ArrayList<List<FloatArray>>()
    private val fragment=ArrayList<FloatArray>()
    private var speechFrames=0
    private var quietFrames=0
    private var enroll=false
    private var lastActivation=0L
    private var threshold=0.32
    init { read() }
    val trained get()=samples.size>=3
    fun startTraining() {
        samples.clear();fragment.clear();enroll=true;quietFrames=0;speechFrames=0
        prefs.edit().remove("templates").apply()
        AssistantBus.update{it.copy(wakeReady=false,enrolling=1,status="Say Aaiyra three times")}
    }
    fun process(frame:ShortArray):Boolean {
        val rms=sqrt(frame.fold(0.0){x,s->x+s.toDouble()*s/32768.0/32768.0}/frame.size).toFloat()
        val speaking=rms>0.022
        if(speaking){
            fragment.add(features(frame))
            speechFrames++;quietFrames=0
        }else if(speechFrames>0){
            quietFrames++
            if(quietFrames<=8)fragment.add(features(frame))
        }
        if(fragment.size>125){fragment.clear();quietFrames=0;speechFrames=0}
        if(speechFrames>10 && quietFrames>=13){
            val utterance=fragment.toList();fragment.clear();quietFrames=0;speechFrames=0
            if(utterance.size !in 12..115)return false
            if(enroll){
                samples.add(utterance)
                AssistantBus.update{it.copy(enrolling=(samples.size+1).coerceAtMost(3),details="Training sample ${samples.size}/3")}
                if(samples.size>=3){enroll=false;calibrate();save();AssistantBus.update{it.copy(wakeReady=true,enrolling=0,status="Aaiyra wake trained (experimental)")}}
                return false
            }
            if(trained && System.currentTimeMillis()-lastActivation>8500){
                val hits=samples.count{dtw(it,utterance)<threshold}
                if(hits>=2){lastActivation=System.currentTimeMillis();return true}
            }
        }
        return false
    }
    private fun features(frame:ShortArray):FloatArray {
        val n=frame.size;val result=FloatArray(frequencies.size)
        frequencies.forEachIndexed{index,f->
            val w=2*PI*f/16000;val coeff=2*cos(w);var a=0.0;var b=0.0
            for(i in frame.indices){val h=frame[i]/32768.0+coeff*a-b;b=a;a=h}
            result[index]=ln(1e-9+a*a+b*b-coeff*a*b).toFloat()
        }
        val mean=result.average().toFloat()
        for(i in result.indices)result[i]=(result[i]-mean).coerceIn(-8f,8f)
        return result
    }
    private fun dtw(a:List<FloatArray>,b:List<FloatArray>):Double {
        val x=DoubleArray(b.size+1){Double.POSITIVE_INFINITY};x[0]=0.0
        for(i in a.indices){
            var diagonal=x[0];x[0]=Double.POSITIVE_INFINITY
            for(j in b.indices){
                val old=x[j+1];var cost=0.0
                for(k in frequencies.indices){val diff=a[i][k]-b[j][k];cost+=diff*diff}
                cost=sqrt(cost/frequencies.size)
                x[j+1]=cost+min(diagonal,min(x[j],old));diagonal=old
            }
        }
        return x[b.size]/max(a.size,b.size).toDouble()
    }
    private fun calibrate(){val vals= mutableListOf<Double>();for(i in 0 until samples.size)for(j in i+1 until samples.size)vals.add(dtw(samples[i],samples[j]));threshold=((vals.average().takeIf{it.isFinite()}?:0.30)*1.12).coerceIn(0.15,1.2)}
    private fun save(){
        val all=JSONArray();samples.forEach{frames->val arr=JSONArray();frames.forEach{f->val row=JSONArray();f.forEach{row.put(it.toDouble())};arr.put(row)};all.put(arr)}
        prefs.edit().putString("templates",all.toString()).putFloat("threshold",threshold.toFloat()).apply()
    }
    private fun read(){
        try{
            val arr=JSONArray(prefs.getString("templates","[]"));samples.clear()
            for(i in 0 until arr.length()){val frames=arr.getJSONArray(i);val phrase=ArrayList<FloatArray>();for(j in 0 until frames.length()){val row=frames.getJSONArray(j);phrase.add(FloatArray(frequencies.size){k->row.getDouble(k).toFloat()})};samples.add(phrase)}
            threshold=prefs.getFloat("threshold",0.32f).toDouble()
        }catch(_:Exception){samples.clear()}
        AssistantBus.update{it.copy(wakeReady=trained)}
    }
}
