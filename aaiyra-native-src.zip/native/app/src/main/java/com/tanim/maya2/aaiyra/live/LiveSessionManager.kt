package com.tanim.maya2.aaiyra.live

import android.util.Base64
import com.tanim.maya2.aaiyra.audio.PcmPlayer
import com.tanim.maya2.aaiyra.tools.ToolExecutionEngine
import com.tanim.maya2.aaiyra.ui.AssistantBus
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** A dedicated thread-safe Live WebSocket session. Voice stream sent as PCM16 16kHz mono. */
class LiveSessionManager(private val tools:ToolExecutionEngine) {
    private val client=OkHttpClient.Builder().pingInterval(20,TimeUnit.SECONDS).readTimeout(0,TimeUnit.MILLISECONDS).build()
    private var ws:WebSocket?=null
    private var player:PcmPlayer?=null
    private val setupComplete=AtomicBoolean(false)
    @Volatile private var running=false
    val connected get()=setupComplete.get()
    fun start(key:String){
        if(running)return
        if(key.isBlank()){AssistantBus.update{it.copy(status="Enter a Gemini API key in Settings")};return}
        player=PcmPlayer();running=true;setupComplete.set(false)
        AssistantBus.update{it.copy(status="Connecting to Gemini Live")}
        val url="wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$key"
        ws=client.newWebSocket(Request.Builder().url(url).build(),object:WebSocketListener(){
            override fun onOpen(webSocket:WebSocket,response:Response){
                val setup=JSONObject().put("model","models/gemini-3.8-live")
                    .put("generationConfig",JSONObject().put("responseModalities",JSONArray().put("AUDIO"))
                        .put("speechConfig",JSONObject().put("voiceConfig",JSONObject().put("prebuiltVoiceConfig",JSONObject().put("voiceName","Aoede")))))
                    .put("systemInstruction",JSONObject().put("parts",JSONArray().put(JSONObject().put("text",PROMPT))))
                    .put("tools",JSONArray().put(JSONObject().put("functionDeclarations",ToolExecutionEngine.declarations)))
                webSocket.send(JSONObject().put("setup",setup).toString())
            }
            override fun onMessage(webSocket:WebSocket,text:String){onServer(text)}
            override fun onMessage(webSocket:WebSocket,bytes:ByteString){onServer(bytes.utf8())}
            override fun onFailure(webSocket:WebSocket,t:Throwable,response:Response?){failed(t.message?:"Network error")}
            override fun onClosed(webSocket:WebSocket,code:Int,reason:String){failed("Live session ended")}
        })
    }
    private fun failed(message:String){setupComplete.set(false);running=false;AssistantBus.update{it.copy(status=message,sessionConnected=false,outputLevel=0f)};player?.interrupt()}
    private fun onServer(text:String){
        try{
            val obj=JSONObject(text)
            if(obj.has("setupComplete")){setupComplete.set(true);AssistantBus.update{it.copy(status="Listening",sessionConnected=true)}}
            val server=obj.optJSONObject("serverContent")
            if(server!=null){
                if(server.optBoolean("interrupted")){player?.interrupt();AssistantBus.update{it.copy(status="Listening")}}
                val parts=server.optJSONObject("modelTurn")?.optJSONArray("parts")
                if(parts!=null)for(i in 0 until parts.length()){
                    val inline=parts.optJSONObject(i)?.optJSONObject("inlineData")
                    if(inline?.optString("mimeType","")?.startsWith("audio/")==true){
                        player?.enqueueB64(inline.optString("data"))
                        AssistantBus.update{it.copy(status="Speaking")}
                    }
                }
                if(server.optBoolean("turnComplete"))AssistantBus.update{it.copy(status="Listening")}
            }
            val call=obj.optJSONObject("toolCall")?.optJSONArray("functionCalls")
            if(call!=null)for(i in 0 until call.length()){
                val fc=call.getJSONObject(i);val id=fc.optString("id");val name=fc.optString("name")
                val result=tools.execute(id,name,fc.optJSONObject("args")?:JSONObject())
                // The model receives a result promptly; for risky tools, it is a confirmation_required status.
                if(result.optString("status") != "confirmation_required") sendToolResult(id,name,result)
            }
        }catch(e:Exception){AssistantBus.update{it.copy(details="Live event: ${e.message}")}}
    }
    fun sendToolResult(id:String,name:String,result:JSONObject){
        ws?.send(JSONObject().put("toolResponse",JSONObject().put("functionResponses",JSONArray()
            .put(JSONObject().put("id",id).put("name",name).put("response",result)))).toString())
    }
    fun sendPcm16(bytes:ByteArray){
        if(!setupComplete.get())return
        // Avoid unbounded WebSocket backlog during weak network conditions.
        val socket=ws?:return;if(socket.queueSize()>250_000L)return
        val frame=JSONObject().put("realtimeInput",JSONObject().put("audio",
            JSONObject().put("mimeType","audio/pcm;rate=16000")
                .put("data",Base64.encodeToString(bytes,Base64.NO_WRAP))))
        socket.send(frame.toString())
    }
    fun interrupt(){player?.interrupt()}
    fun stop(){running=false;setupComplete.set(false);ws?.close(1000,"Stopped by user");ws=null;player?.close();player=null;AssistantBus.update{it.copy(sessionConnected=false,outputLevel=0f)}}
    companion object { const val PROMPT="""You are Aaiyra inside Maya, a witty, confident, caring young-adult female voice companion. Speak naturally, be playful, teasing and slightly sassy without inappropriate content. Answer in the user's language. Keep replies short and conversational. Device tools: only use them on user's clear request. For calls, messages and email, respect confirmation_required results; never claim an action completed unless result confirms it. You cannot read private past chats or send messages silently. If permission is missing, warmly ask user to enable it. Do not pretend to be a real human.""" }
}
